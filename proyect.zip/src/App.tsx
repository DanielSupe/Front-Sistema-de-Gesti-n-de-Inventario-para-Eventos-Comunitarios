import { useEffect, useState } from 'react'
import './App.css'
import { useDispatch, useSelector } from 'react-redux';
import { fetchInventory } from './store/inventory/inventoryThunk';
import DynamicTable from './custom/Components/DynamicTable';

function App() {
  const dispatch = useDispatch();
  const {loading, inventory} = useSelector((state: any) => state.inventory)
  const [inventoryList, setInventoryList] = useState([]);

  const columns = [
  { name: 'ID', key: 'id' },
  { name: 'Item ID', key: 'itemId' },
  { name: 'Cantidad', key: 'quantity' },
  { name: 'Fecha inicio', key: 'startDate' },
  { name: 'Fecha fin', key: 'endDate' },
  { name: 'Solicitado por', key: 'requestedBy' },
];

  useEffect(() => {
    setInventoryList(inventory);
  }, [inventory]);

  useEffect(() => {
    dispatch<any>(fetchInventory())
  }, []);

    const handleRowClick = (rowData: any) => {
    console.log('Fila seleccionada:', rowData);
  };



  return (
    <>
    <div className="bg-blue-500 text-white p-4">
      hola
      {/* <DynamicTable
        data={inventoryList}
        columns={columns}
        actionRowClick={handleRowClick}
      /> */}
    </div>
    </>
  )
}

export default App
