import React from 'react';

type Column = {
  name: string;
  key: string;
  hidden?: boolean;
};

type DynamicTableProps = {
  data: Record<string, any>[];
  columns: Column[];
  actionRowClick?: (rowData: Record<string, any>) => void;
};

const DynamicTable: React.FC<DynamicTableProps> = ({ data, columns, actionRowClick }) => {
  const visibleColumns = columns.filter((col) => !col.hidden);

  return (
    <div className="overflow-auto p-4 bg-red-100">
      <table className="min-w-full divide-y divide-gray-200 shadow-md rounded-md overflow-hidden bg-white">
        <thead className="bg-blue-600 text-white">
          <tr>
            {visibleColumns.map((col) => (
              <th
                key={col.key}
                className="px-6 py-3 text-left text-sm font-semibold tracking-wider"
              >
                {col.name}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 text-gray-700">
          {data.map((row, idx) => (
            <tr
              key={idx}
              className="hover:bg-blue-50 cursor-pointer transition"
              onClick={() => actionRowClick?.(row)}
            >
              {visibleColumns.map((col) => (
                <td
                  key={col.key}
                  className="px-6 py-3 whitespace-nowrap text-sm"
                >
                  {row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DynamicTable;
