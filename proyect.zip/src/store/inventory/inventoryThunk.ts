
import axios from "axios";
import { urlBack } from "../../helpers/url_helper";
import type { AppDispatch } from "../store";
import { getinventory, getinventoryFail, getinventorySuccess } from "./inventorySlice";



export const fetchInventory = () => async (dispatch: AppDispatch) => {
  dispatch(getinventory());

  try {
    // const response = await axios.get(`${urlBack}/inventory`);

    const response = [
  {
    id: 1,
    itemId: 101,
    quantity: 2,
    startDate: Date.now() + 1000 * 60 * 60 * 24, // mañana
    endDate: Date.now() + 1000 * 60 * 60 * 48,   // pasado mañana
    requestedBy: 'Alice'
  },
  {
    id: 2,
    itemId: 102,
    quantity: 1,
    startDate: Date.now() + 1000 * 60 * 60 * 24 * 2, // en 2 días
    endDate: Date.now() + 1000 * 60 * 60 * 24 * 3,   // en 3 días
    requestedBy: 'Bob'
  },
  {
    id: 3,
    itemId: 103,
    quantity: 5,
    startDate: Date.now() + 1000 * 60 * 60 * 6, // en 6 horas
    endDate: Date.now() + 1000 * 60 * 60 * 30,  // en 1.25 días
    requestedBy: 'Carlos'
  },
  {
    id: 4,
    itemId: 104,
    quantity: 3,
    startDate: Date.now() + 1000 * 60 * 60 * 12, // en 12 horas
    endDate: Date.now() + 1000 * 60 * 60 * 36,   // en 1.5 días
    requestedBy: 'Diana'
  },
  {
    id: 5,
    itemId: 105,
    quantity: 10,
    startDate: Date.now() + 1000 * 60 * 60 * 24 * 5, // en 5 días
    endDate: Date.now() + 1000 * 60 * 60 * 24 * 7,   // en 7 días
    requestedBy: 'Elena'
  }
];


    dispatch(getinventorySuccess(response));
  } catch (err: any) {
    dispatch(getinventoryFail(err.message || 'Error fetching inventory'));
  }
};